
- list package
    ```
    pip3 list | grep ft  
    ```
- uninstall package
    ```
    pip3 uninstall
    ```
- ensure package is there
    ```
    pip3 install setuptools wheel
    ```
- create dist
    ```
    python setup.py sdist bdist_wheel
    ```